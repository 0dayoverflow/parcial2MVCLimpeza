package mvc;

import java.util.TimerTask;
import javax.swing.JFrame;
import vista.inicioSesion;
import vista.jefe;
import javax.swing.JPanel;
import java.util.Timer;

public class app {

    static JFrame ventana = new JFrame();

    public static void setpane(JPanel pane) {

        ventana.setContentPane(pane);
        ventana.setSize(pane.getLayout().preferredLayoutSize(pane));

    }

    public static void main(String[] args) {

        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        inicioSesion is = new inicioSesion();
        setpane(is);
        TimerTask si = new TimerTask() {
            @Override
            public void run() {
                if (is.inicio) {
                    setpane(new jefe());
                }

            }

        };
        Timer tiempo = new Timer();
        tiempo.scheduleAtFixedRate(si, 0, 1000);

        ventana.setVisible(true);

    }

}
