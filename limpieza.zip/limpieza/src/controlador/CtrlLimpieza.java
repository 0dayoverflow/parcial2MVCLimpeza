package controlador;


public class CtrlLimpieza {
    
}
