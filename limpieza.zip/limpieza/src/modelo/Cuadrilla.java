package modelo;


public class Cuadrilla {
    private int id_jefe;
    private String nombreCuadrilla;

    public Cuadrilla(int id_jefe, String nombreCuadrilla) {
        this.id_jefe = id_jefe;
        this.nombreCuadrilla = nombreCuadrilla;
    }

    public int getId_jefe() {
        return id_jefe;
    }

    public void setId_jefe(int id_jefe) {
        this.id_jefe = id_jefe;
    }

    public String getNombreCuadrilla() {
        return nombreCuadrilla;
    }

    public void setNombreCuadrilla(String nombreCuadrilla) {
        this.nombreCuadrilla = nombreCuadrilla;
    }
    
    
}
