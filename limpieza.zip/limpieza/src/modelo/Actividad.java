package modelo;


public class Actividad {
    private int idactividad;
   private String estado,detalles ,cuadrilla_nombre;

    public Actividad(int idactividad, String estado, String detalles, String cuadrilla_nombre) {
        this.idactividad = idactividad;
        this.estado = estado;
        this.detalles = detalles;
        this.cuadrilla_nombre = cuadrilla_nombre;
    }

    public Actividad(int idactividad) {
        this.idactividad = idactividad;
    }

    public int getIdactividad() {
        return idactividad;
    }

    public void setIdactividad(int idactividad) {
        this.idactividad = idactividad;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getDetalles() {
        return detalles;
    }

    public void setDetalles(String detalles) {
        this.detalles = detalles;
    }

    public String getCuadrilla_nombre() {
        return cuadrilla_nombre;
    }

    public void setCuadrilla_nombre(String cuadrilla_nombre) {
        this.cuadrilla_nombre = cuadrilla_nombre;
    }
    
    
    
    
}
