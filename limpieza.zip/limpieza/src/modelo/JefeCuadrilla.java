package modelo;

public class JefeCuadrilla {
   private int idjefe;
    private String nombre;

    public JefeCuadrilla(int idjefe, String nombre) {
        this.idjefe = idjefe;
        this.nombre = nombre;
    }

    public int getIdjefe() {
        return idjefe;
    }

    public void setIdjefe(int idjefe) {
        this.idjefe = idjefe;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
}
