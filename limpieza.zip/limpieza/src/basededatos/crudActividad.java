package basededatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import modelo.Actividad;

public class crudActividad {
    static Connection con;
  public static void create (Actividad objeto){    
  }
  public static void read(Actividad objeto){
      
  }
   public static void update(Actividad objeto){
      
  }
    public static void delete(Actividad objeto){
      
  }
    private static void conectar() throws SQLException{
        con= DriverManager.getConnection("jdbc:mysql://localhost:3306/limpieza","root","");
    }
}
